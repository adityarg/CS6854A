Run "assign1.sh" to run all scripts.

Code to question 1 is in "ques-1.py", takes input from covid19 api and "neighbor-districts.json" and outputs "neighbor-districts-modified.json".

Code to question 3 is in "ques-3.py" takes imput from "neighbor-districts-modified.json" and output "edge-graph.csv"

Script "edge-generator.sh" runs the code of question 3.