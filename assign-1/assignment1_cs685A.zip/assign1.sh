#!/bin/bash

python3 ques-1.py
./edge-generator.sh