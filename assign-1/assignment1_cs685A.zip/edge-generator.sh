#!/bin/bash

python3 ques-3.py
