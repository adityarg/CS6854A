import json
import requests

# Importing data from Covid-19 API
f = open('neighbor-districts.json')
odt = json.load(f)
res = requests.get("https://api.covid19india.org/v4/data-all.json")
# print(res.status_code)
repo = res.json()

# keys of API data
ky = list(repo['2020-09-23'].keys())

# 
dist = []
for x in ky:
    if 'districts' in repo['2020-09-05'][x]:
        dist.extend(list(repo['2020-09-05'][x]['districts'].keys()))
while 'Unknown' in dist:
    dist.remove('Unknown')
dist=[x.lower() for x in dist]
dist.sort()


# Importing given district data
f = open('neighbor-districts.json')
odt = json.load(f)

# function to change name of the district in 'odt'
def corr(new,old):
    x=''
    for y in list(odt.keys()):
        if y.split('/')[0].replace('_',' ')==old.replace('_',' '):
            x=y.split('/')[1]
    new=new+'/'+x; new=new.replace(' ','_')
    old=old+'/'+x; old=old.replace(' ','_')
    odt[new]=odt[old]
    del odt[old]
    for x in odt:
        for i in range(len(odt[x])):
            if odt[x][i]==old:
                odt[x][i]=new

# ##########################
corr('ferozepur','firozpur')
corr('aizawl','aizwal')
corr('angul','anugul')
corr('ashoknagar','ashok nagar')
corr('ballari','nalbari')
corr('bametara','bemetara')
corr('baramulla','baramula')
corr('budgam','badgam')
corr('boudh','baudh')
corr('deogarh','debagarh')
corr('dholpur','dhaulpur')
corr('fatehgarh sahib','fategarh sahib')
corr('gondia','gondiya')
corr('jagatsinghpur','jagatsinghapur')
corr('jajpur','jajapur')
corr('pakur','pakaur')
corr('pathanamthitta','pattanamtitta')
corr('purulia','puruliya')
corr('rajouri','rajauri')
corr('jalore','jalor')
corr('lahaul and spiti','lahul and spiti')
corr('sant kabir nagar','sait kibir nagar')
corr('shahid bhagat singh nagar','shaheed bhagat singh nagar')
corr('sipahijala','sepahijala')
corr('shopiyan','shopian')
corr('shrawasti','sharawasti')
corr('koderma','kodarma')
corr('maharajganj','mahrajganj')
corr('malda','maldah')
corr('nandurbar','nandubar')
corr('jhunjhunu','jhunjhunun')
corr('kabeerdham','kabirdham')
corr('siddharthnagar','siddharth nagar')
corr('ahmedabad','ahmedabad district')
corr('amreli','amreli_district')
corr('anand','anand_district')
corr('anantapur','anantapur_district')
corr('aravalli','aravalli_district')
corr('ariyalur','ariyalur_district')
corr('bagalkote','bagalkote_district')
corr('bengaluru urban','bangalore_urban')
corr('bengaluru rural','bangalore_rural')
corr('bharuch','bharuch_district')
corr('bhavnagar','bhavnagar_district')
corr('bhiwani','bhiwani_district')
corr('botad','botad_district')
corr('chamarajanagara','chamarajanagar_district')
corr('chennai','chennai_district')
corr('chhota udaipur','chhota_udaipur_district')
corr('chikkaballapura','chikkaballapura_district')
corr('banaskantha','banas_kantha_district')
corr('belagavi','belgaum_district')
corr('chikkamagaluru','chikkamagaluru_district')
corr('chitradurga','chitradurga_district')
corr('coimbatore','coimbatore_district')
corr('cooch behar','kochbihar')
corr('cuddalore','cuddalore_district')
corr('dahod','dahod_district')
corr('dakshin bastar dantewada','dantewada')
corr('dang','the_dangs')
corr('davanagere','davanagere_district')
corr('devbhumi dwarka','devbhumi_dwaraka_district')
corr('dharmapuri','dharmapuri_district')
corr('dharwad','dharwad_district')
corr('dindigul','dindigul_district')
corr('east champaran','purba_champaran')
corr('east singhbhum','purbi_singhbhum')
corr('theni','theni_district')
corr('kheda','kheda_district')
corr('karur','karur_district')
corr('beed','bid')
corr('bidar','bidar_district')
corr('balasore','baleshwar')
corr('erode','erode_district')
corr('gadag','gadag_district')
corr('gandhinagar','gandhinagar_district')
corr('ganganagar','sri_ganganagar')
corr('gir somnath','gir_somnath_district')
corr('hassan','hassan_district')
corr('haveri','haveri_district')
corr('hoogli','hugli')
corr('jamnagar','jamnagar_district')
corr('junagadh','junagadh_district')
corr('kaimur','kaimur_(bhabua)')
corr('kalaburagi','kalaburagi_district')
corr('kancheepuram','kanchipuram_district')
corr('kannur','kannur_district')
corr('kanyakumari','kanyakumari_district')
corr('kargil','kargil_district')
corr('kasaragod','kasaragod_district')
corr('kolar','kolar_district')
corr('koppal','koppal_district')
corr('kurung kumey','kurung_kumey_district')
corr('kutch','kutch_district')
corr('leh','leh_district')
corr('madurai','madurai_district')
corr('mahisagar','mahisagar_district')
corr('mandya','mandya_district')
corr('mehsana','mahesana_district')
corr('morbi','morbi_district')
corr('mysuru','mysuru_district')
corr('nagapattinam','nagapattinam_district')
corr('namakkal','namakkal_district')
corr('narmada','narmada_district')
corr('narsinghpur','narsimhapur')
corr('navsari','nav_sari_district')
corr('nilgiris','the_nilgiris_district')
corr('palakkad','palghat')
corr('panchmahal','panch_mahal_district')
corr('perambalur','perambalur_district')
corr('porbandar','porbandar_district')
corr('puducherry','puducherry_district')
corr('pudukkottai','pudukkottai_district')
corr('pune','pune_district')
corr('rae bareli','rae_bareilly')
corr('raichur','raichur_district')
corr('ramanagara','ramanagara_district')
corr('ramanathapuram','ramanathapuram_district')
corr('s.a.s. nagar','sahibzada_ajit_singh_nagar')
corr('s.p.s. nellore','sri_potti_sriramulu_nellore')
corr('sabarkantha','sabar_kantha_district')
corr('salem','salem_district')
corr('sangli','sangli_district')
corr('saraikela-kharsawan','seraikela_kharsawan')
corr('shivamogga','shimoga_district')
corr('sivaganga','sivagangai_district')
corr('sri muktsar sahib','muktsar')
corr('subarnapur','sonapur')
corr('surendranagar','surendranagar_district')
corr('tapi','tapi_district')
corr('tawang','tawang_district')
corr('thanjavur','thanjavur_district')
corr('thiruvallur','thiruvallur_district')
corr('thiruvarur','thiruvarur_district')
corr('thoothukudi','thoothukudi_district')
corr('tiruchirappalli','tiruchchirappalli_district')
corr('tirunelveli','tirunelveli_kattabo')
corr('tiruvannamalai','tiruvanamalai_district')
corr('tumakuru','tumkur_district')
corr('udupi','udupi_district')
corr('vadodara','vadodara_district')
corr('vellore','vellore_district')
corr('viluppuram','viluppuram_district')
corr('virudhunagar','virudhunagar_district')
corr('west champaran','pashchim_champaran')
corr('west kameng','west_kameng_district')
corr('west singhbhum','pashchimi_singhbhum')
corr('y.s.r. kadapa','ysr')
corr('yadagir','yadagiri_district')

temp=odt['mumbai_suburban/Q2085374']
del odt['mumbai_suburban/Q2085374']
temp.extend(odt['mumbai_city/Q2341660'])
del odt['mumbai_city/Q2341660']
odt['mumbai/Q2595374']=temp
for x in odt:
        for i in range(len(odt[x])):
            if odt[x][i]=='mumbai_suburban/Q2085374' or odt[x][i]=='mumbai_city/Q2341660':
                odt[x][i]='mumbai/Q2595374'

temp=odt['bijapur_district/Q1727570']; del odt['bijapur_district/Q1727570']
odt['vijayapura/Q1722370']=temp
for x in odt:
        for i in range(len(odt[x])):
            if odt[x][i]=='bijapur_district/Q1727570':
                odt[x][i]='vijayapura/Q1722370'

temp=odt['central_delhi/Q107941']; del odt['central_delhi/Q107941']
temp.extend(odt['new_delhi/Q987']); del odt['new_delhi/Q987']
temp.extend(odt['north_delhi/Q693367']); del odt['north_delhi/Q693367']
temp.extend(odt['north_east_delhi/Q429329']); del odt['north_east_delhi/Q429329']
temp.extend(odt['north_west_delhi/Q766125']); del odt['north_west_delhi/Q766125']
temp.extend(odt['south_delhi/Q2061938']); del odt['south_delhi/Q2061938']
temp.extend(odt['south_east_delhi/Q25553535']); del odt['south_east_delhi/Q25553535']
temp.extend(odt['south_west_delhi/Q2379189']); del odt['south_west_delhi/Q2379189']
temp.extend(odt['west_delhi/Q549807']); del odt['west_delhi/Q549807']
temp.extend(odt['east_delhi/Q107960']); del odt['east_delhi/Q107960']
odt['delhi/Q549852']=temp
for x in odt:
        for i in range(len(odt[x])):
            if odt[x][i]=='central_delhi/Q107941' or odt[x][i]=='new_delhi/Q987' or odt[x][i]=='north_delhi/Q693367' or odt[x][i]=='north_east_delhi/Q429329' or odt[x][i]=='north_west_delhi/Q766125' or odt[x][i]=='south_delhi/Q2061938' or odt[x][i]=='south_east_delhi/Q25553535' or odt[x][i]=='south_west_delhi/Q2379189' or odt[x][i]=='west_delhi/Q549807' or odt[x][i]=='east_delhi/Q107960':
                odt[x][i]='delhi/Q549852'

temp=odt['lower_dibang_valley/Q2373368']; del odt['lower_dibang_valley/Q2373368']
temp.extend(odt['upper_dibang_valley/Q15446']); del odt['upper_dibang_valley/Q15446']
odt['dibang valley/Q154456']=temp
for x in odt:
        for i in range(len(odt[x])):
            if odt[x][i]=='lower_dibang_valley/Q2373368' or odt[x][i]=='upper_dibang_valley/Q15446':
                odt[x][i]='dibang valley/Q154456'

odt['amroha']=[]
odt['ayodhya']=[]
odt['bhadohi']=[]
odt['chengalpattu']=[]
odt['balasore']=[]

odt['janjgir champa/Q2575633']=odt['janjgir-champa/Q2575633']
del odt['janjgir-champa/Q2575633']
for x in odt:
    for i in range(len(odt[x])):
        if odt[x][i]=='janjgir-champa/Q2575633':
            odt[x][i]='janjgir champa/Q2575633'

odt['ribhoi/Q1884672']=odt['ri-bhoi/Q1884672']
del odt['ri-bhoi/Q1884672']
for x in odt:
    for i in range(len(odt[x])):
        if odt[x][i]=='ri-bhoi/Q1884672':
            odt[x][i]='ri bhoi/Q1884672'

# ##########################


# ddata = [x.split('/')[0].replace('_',' ') for x in list(odt.keys())]
# ddata.sort()

# Exporting modified data
obj = json.dumps(odt, indent = 4)
with open("neighbor-districts-modified.json","w") as outfile:
	outfile.write(obj)