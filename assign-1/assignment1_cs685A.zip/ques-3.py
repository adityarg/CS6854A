import pandas as pd
import json

f = open('neighbor-districts-modified.json')
odt = json.load(f)
df = pd.DataFrame(columns = ['District_1','District_2'])

(df['District_1']=='adi').any()
for i in odt:
    for j in odt[i]:
        if ((df['District_1']==i).any() and (df['District_2']==j).any()) or\
        ((df['District_1']==j).any() and (df['District_2']==i).any()):
            continue
        df=df.append({'District_1' : i, 'District_2' : j},ignore_index=True)
df.to_csv('edge-graph.csv')