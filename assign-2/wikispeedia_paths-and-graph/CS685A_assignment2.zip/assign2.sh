#!/bin/bash

python3 fullcode.py